package com.example.infs3634finalassignmentv3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Quiz extends AppCompatActivity {
    List<QuestionInformation> question_list;
    Button option1_button;
    Button option2_button;
    Button option3_button;
    Button option4_button;
    TextView question_textview;
    TextView question_count_textview;
    TextView correct_textview;
    TextView wrong_textview;
    LinearLayout row1;
    LinearLayout row2;
    LinearLayout row3;
    LinearLayout row4;
    Random r_id;
    Random r_qid;
    int id;
    int q_count;
    int correct_answers;
    int wrong_answers;
    int quiz_end_count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        question_textview = findViewById(R.id.question_textview);
        question_count_textview = findViewById(R.id.question_count_textview);
        correct_textview = findViewById(R.id.correct_textview);
        wrong_textview = findViewById(R.id.wrong_textview);
        option1_button = findViewById(R.id.option1_button);
        option2_button = findViewById(R.id.option2_button);
        option3_button = findViewById(R.id.option3_button);
        option4_button = findViewById(R.id.option4_button);
        row1 = findViewById(R.id.row1);
        row2 = findViewById(R.id.row2);
        row3 = findViewById(R.id.row3);
        row4 = findViewById(R.id.row4);
        setQuiz();

        option1_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                nextQuestion(option1_button.getText().toString());
            }
        });
        option2_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                nextQuestion(option2_button.getText().toString());
            }
        });

        option3_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                nextQuestion(option3_button.getText().toString());
            }
        });

        option4_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                nextQuestion(option4_button.getText().toString());
            }
        });
    }

    public void setQuiz(){
        question_list = new ArrayList<>();
        for (int i = 0; i < new QuizBank().answers.length; i++){
            question_list.add(new QuestionInformation(new QuizBank().q_id[i], new QuizBank().questions[i], new QuizBank().answers[i]));
        }

        q_count = 1;
        id = 2;
        question_textview.setText(question_list.get(id).getQuestion());
        option1_button.setText(question_list.get(0).getAnswer());
        option2_button.setText(question_list.get(1).getAnswer());
        option3_button.setText(question_list.get(id).getAnswer());
        option4_button.setText(question_list.get(3).getAnswer());
    }

    public void nextQuestion(String answer_name) {
        r_id = new Random();
        r_qid = new Random();
        boolean answer;

        if (answer_name == question_list.get(id).getAnswer()) {
            answer = true;
            Toast.makeText(Quiz.this, "Correct!", Toast.LENGTH_SHORT).show();
            correct_answers = correct_answers + 1;
            correct_textview.setText("Correct: " + Integer.toString(correct_answers));


        } else {
            answer = false;
            wrong_answers = wrong_answers +  1;
            wrong_textview.setText("Wrong: " + Integer.toString(wrong_answers));
            Toast.makeText(Quiz.this, "Wrong!", Toast.LENGTH_SHORT).show();
        }


        if (q_count >= 19) {
            endQuiz(Integer.toString(correct_answers));
        }

        id = r_id.nextInt(35);
        int qid = r_qid.nextInt(3);
        q_count = q_count + 1;
        String question_count;
        question_count = "Question " + Integer.toString(q_count);
        question_count_textview.setText(question_count);

        Log.d("LMAO", "Entering Correct Answer Sequence");
        Log.d("LMAO", Integer.toString(id));
        Log.d("LMAO", Integer.toString(question_list.size()));
        Log.d("LMAO", Integer.toString(qid));

        question_textview.setText(question_list.get(id).getQuestion());

        if (qid == 0) {
            option1_button.setText(question_list.get(id).getAnswer());
            option2_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option3_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option4_button.setText(question_list.get(exceptRand(id)).getAnswer());
        }else if(qid == 1) {
            option2_button.setText(question_list.get(id).getAnswer());
            option1_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option3_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option4_button.setText(question_list.get(exceptRand(id)).getAnswer());
        } else if (qid == 2){
            option3_button.setText(question_list.get(id).getAnswer());
            option1_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option2_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option4_button.setText(question_list.get(exceptRand(id)).getAnswer());
        }else if(qid == 3){
            option4_button.setText(question_list.get(id).getAnswer());
            option2_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option3_button.setText(question_list.get(exceptRand(id)).getAnswer());
            option1_button.setText(question_list.get(exceptRand(id)).getAnswer());
        }

        //row1.setBackgroundResource(R.drawable.roundedborder1);
        //row2.setBackgroundResource(R.drawable.roundedborder2);
        //row3.setBackgroundResource(R.drawable.roundedborder3);
        //row4.setBackgroundResource(R.drawable.roundedborder4);

    }

    public int exceptRand(int rand){

        Random rando = new Random();
        int magic;
        do {
            magic = rando.nextInt(35);
        } while (magic == rand);
        return magic;
    }

    public void endQuiz(String score) {
        Intent intent = new Intent(this, ScoreScreen.class);
        Bundle extras = new Bundle();
        extras.putString("final_score", score);
        intent.putExtras(extras);
        startActivity(intent);
    }
}
